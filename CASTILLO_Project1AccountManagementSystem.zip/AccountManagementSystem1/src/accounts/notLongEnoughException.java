package accounts;

public class notLongEnoughException extends Exception {

}
