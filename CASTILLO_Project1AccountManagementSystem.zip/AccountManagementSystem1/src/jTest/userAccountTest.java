package jTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import accounts.AccountBag;
import accounts.UserAccountFactory;

class userAccountTest {

	@Test
	void lowerCaseTest() {
		UserAccountFactory userAccountFactory = new UserAccountFactory();
		String password = "";
		
		//assertTrue(userAccountFactory.hasLowerCase(password));
		
	
	}

}
