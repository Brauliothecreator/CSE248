package Names;

public class Demo {

	public static void main(String[] args) {

		NameWarehouse nw = new NameWarehouse();
		
		}

}
