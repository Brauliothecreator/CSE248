In this project to store my Accounts I used a HashSet that has a comparable method to prevent having duplicate user Names.
The insertion of accounts is (O)1 and to search also returns (O)1.
When the text files were read and put into an array the big was (O)n also to go through the array to get random objects in the Array was (O)1
All Test had to go through a String at certain index so that would be (O)n.